from flask import Flask,render_template,request,redirect,url_for,session
from pathlib import Path
import pickle,pandas as pd
app=Flask(__name__); app.secret_key='mindtrack-demo-secret'
BASE=Path(__file__).resolve().parent
with open(BASE/'model/mental_health_model.pkl','rb') as f: bundle=pickle.load(f)
model=bundle['pipeline']; ACC=round(bundle['accuracy']*100,1)
COURSES=['Computer Science','Engineering','Business','Arts','Science']
def clamp(x,a,b): return max(a,min(b,x))
def tips(d):
    t=[]
    if d['sleep_hours']<7:t.append('Aim for a consistent sleep routine and around 7–9 hours of sleep.')
    if d['academic_pressure']>=7:t.append('Break large academic tasks into smaller goals and schedule regular breaks.')
    if d['social_support']<=4:t.append('Stay connected with trusted friends, classmates, family, or a mentor.')
    if d['exercise_days']<3:t.append('Add light physical activity several days a week if practical for you.')
    if d['workload']>=7:t.append('Prioritize deadlines and avoid stacking too many demanding tasks together.')
    if d['loneliness']>=7:t.append('Consider supportive social or campus activities.')
    if d['screen_time']>=9:t.append('Try screen-free study breaks and a calmer wind-down routine before sleep.')
    if d['attendance']<75:t.append('If attendance is becoming difficult, speak with an academic advisor.')
    return t or ['Keep your current routines and continue monitoring sleep, workload, support, and study balance.']
def message(r):
    return {'Low Risk':'Your responses suggest a lower level of reported risk. Keep supporting sleep, routine, relationships, and study balance.',
    'Moderate Risk':'Your responses show some areas that may deserve attention. Small changes to workload, sleep, support, and routines may help.',
    'High Risk':'Your responses indicate several areas that may need attention. Consider talking with a trusted person or an appropriate campus support service.'}[r]
@app.route('/')
def index(): return render_template('index.html',accuracy=ACC)
@app.route('/input')
def input_page(): return render_template('input.html',courses=COURSES)
@app.route('/predict',methods=['POST'])
def predict():
    d={k:request.form[k] for k in ['gender','course']}
    d.update({k:float(request.form[k]) for k in ['study_hours','sleep_hours','attendance','screen_time']})
    d.update({k:int(request.form[k]) for k in ['age','academic_pressure','social_support','exercise_days','workload','loneliness']})
    d['age']=clamp(d['age'],16,80); d['study_hours']=clamp(d['study_hours'],0,24); d['sleep_hours']=clamp(d['sleep_hours'],0,14)
    d['academic_pressure']=clamp(d['academic_pressure'],1,10); d['social_support']=clamp(d['social_support'],1,10)
    d['exercise_days']=clamp(d['exercise_days'],0,7); d['attendance']=clamp(d['attendance'],0,100)
    d['workload']=clamp(d['workload'],1,10); d['loneliness']=clamp(d['loneliness'],1,10); d['screen_time']=clamp(d['screen_time'],0,24)
    frame=pd.DataFrame([d]); risk=model.predict(frame)[0]; conf=round(max(model.predict_proba(frame)[0])*100,1)
    d.update(risk=risk,confidence=conf,message=message(risk),tips=tips(d)); session['result']=d
    return redirect(url_for('result'))
@app.route('/result')
def result():
    d=session.get('result'); return redirect(url_for('input_page')) if not d else render_template('result.html',data=d,accuracy=ACC)
@app.route('/dashboard')
def dashboard():
    d=session.get('result'); return redirect(url_for('input_page')) if not d else render_template('dashboard.html',data=d)
@app.route('/reset')
def reset(): session.clear(); return redirect(url_for('index'))
if __name__=='__main__': app.run(debug=True)
