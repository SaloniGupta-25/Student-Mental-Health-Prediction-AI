# Student Mental Health Prediction
Educational Flask + Random Forest project for estimating a general student wellness risk level from synthetic data.

**Not a medical diagnosis or clinical assessment.**

## Run
```bash
cd Student-Mental-Health-Prediction
python -m venv venv
# Windows:
venv\Scripts\activate
pip install -r requirements.txt
python model/train_model.py
python app.py
```
Open http://127.0.0.1:5000
