from pathlib import Path
import pickle, pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.metrics import accuracy_score
BASE=Path(__file__).resolve().parent.parent
df=pd.read_csv(BASE/'dataset/mental_health_data.csv')
features=['age','gender','course','study_hours','sleep_hours','academic_pressure','social_support','exercise_days','attendance','workload','loneliness','screen_time']
cat=['gender','course']; num=[x for x in features if x not in cat]
prep=ColumnTransformer([('cat',OneHotEncoder(handle_unknown='ignore'),cat),('num','passthrough',num)])
pipe=Pipeline([('preprocessor',prep),('classifier',RandomForestClassifier(n_estimators=250,max_depth=10,min_samples_split=6,random_state=42,class_weight='balanced'))])
Xtr,Xte,ytr,yte=train_test_split(df[features],df.risk_level,test_size=.2,random_state=42,stratify=df.risk_level)
pipe.fit(Xtr,ytr); acc=accuracy_score(yte,pipe.predict(Xte))
with open(BASE/'model/mental_health_model.pkl','wb') as f: pickle.dump({'pipeline':pipe,'features':features,'accuracy':acc},f)
print(f'Model accuracy: {acc*100:.2f}%')
